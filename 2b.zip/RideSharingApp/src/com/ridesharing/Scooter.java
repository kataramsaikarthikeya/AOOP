package com.ridesharing;

public class Scooter implements Vehicle {
    @Override
    public void ride() {
        System.out.println("Riding a scooter...");
    }

}
